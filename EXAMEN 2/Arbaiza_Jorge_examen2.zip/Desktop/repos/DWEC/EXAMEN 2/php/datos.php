<?php

$nombre=$_GET['nombre'];
$mail=$_GET['mail'];

echo $nombre. " recibirás en breve información al correo ".$mail;

?>