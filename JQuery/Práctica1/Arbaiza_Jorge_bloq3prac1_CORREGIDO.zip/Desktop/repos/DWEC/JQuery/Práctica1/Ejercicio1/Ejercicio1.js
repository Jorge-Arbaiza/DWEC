$(document).ready(function () {
var div_count = $("div");
alert("Hay "+ div_count.length + " divs.");
div_count.css("color", "green")
});
