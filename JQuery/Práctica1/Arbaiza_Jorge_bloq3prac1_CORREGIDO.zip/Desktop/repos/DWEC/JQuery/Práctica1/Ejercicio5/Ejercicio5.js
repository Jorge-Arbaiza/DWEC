$(document).ready(function () {
    $("p").mouseover(function () {
        $("p").addClass("aumenta")
    });
    $("p").mouseout(function () {
        $("p").removeClass("aumenta")
    });
    
});