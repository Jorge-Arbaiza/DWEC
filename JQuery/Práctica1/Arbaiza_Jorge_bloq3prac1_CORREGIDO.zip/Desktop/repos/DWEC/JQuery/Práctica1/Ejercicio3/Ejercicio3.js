$(document).ready(function () {
    $("#red").click(function () {
        $("p").css("background-color", "red")
    });
    $("#blue").click(function () {
        $("p").css("background-color", "blue")
    });
    $("#green").click(function () {
        $("p").css("background-color", "green")
    });
});