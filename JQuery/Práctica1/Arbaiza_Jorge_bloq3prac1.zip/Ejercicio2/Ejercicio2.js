$(document).ready(function () {
    $("#hide").click(function () {
        $("#pikachu").hide("slow")
    });
    $("#show").click(function () {
        $("#pikachu").show(2500)
    })
});