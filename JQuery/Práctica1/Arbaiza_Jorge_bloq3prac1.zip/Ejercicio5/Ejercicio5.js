$(document).ready(function () {
    $("p").mouseover(function () {
        $("p").css("font-size", "16pt")
    });
    $("p").mouseout(function () {
        $("p").css("font-size", "")
    });
    
});