$(document).ready(function () {
   $("#despedida").click(function (){
      
    $("#texto").fadeOut("slow");
   });
   $("#saludo").click(function (){
      
    $("#texto").fadeIn("slow");
   });
   
   
        });
  