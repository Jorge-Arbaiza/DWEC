$(document).ready(function () {
   $("#despedida").click(function (){
      
    $("#texto").animate({
        opacity: 0
    });
   });
   $("#saludo").click(function (){
      
    $("#texto").animate({
        opacity: 1
    });
   });
   
   
        });
  