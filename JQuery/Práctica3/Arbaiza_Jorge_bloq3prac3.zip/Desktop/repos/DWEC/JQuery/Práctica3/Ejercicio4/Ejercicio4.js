$(document).ready(function () {
 h1 = $("h1")
 h1.click(function(){
     
     h1.animate({
         color: "blue"
     })
 })
        });
  