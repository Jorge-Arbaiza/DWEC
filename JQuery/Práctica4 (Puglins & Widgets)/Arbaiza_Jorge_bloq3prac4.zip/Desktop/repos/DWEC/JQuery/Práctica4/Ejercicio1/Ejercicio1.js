$(document).ready(function(){
    $("#boton").click(function(){
        $("p").desaparece()
    })
})

  