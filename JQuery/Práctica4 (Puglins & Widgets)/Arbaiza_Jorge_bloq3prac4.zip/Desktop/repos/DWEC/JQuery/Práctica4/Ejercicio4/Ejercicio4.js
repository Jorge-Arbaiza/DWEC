
$(document).ready(function(){
    $('.your-class').slick();
  });

  