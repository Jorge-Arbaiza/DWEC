
$(document).ready(function(){
    $("#boton").click(function(){
        $("div").miPlugin();
    });
});

  