$(function () {
  $("#accordion").accordion();
});
$(document).ready(function () {
  $('.your-class').slick();
});


