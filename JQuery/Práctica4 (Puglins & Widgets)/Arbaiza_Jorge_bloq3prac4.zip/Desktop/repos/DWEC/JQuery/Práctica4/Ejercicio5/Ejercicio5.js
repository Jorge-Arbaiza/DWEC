
  $( function() {
    $( "#accordion" ).accordion();
  } );

  