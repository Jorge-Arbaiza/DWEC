var fecha=new Date();
document.write(fecha.getDate()+'/'+fecha.getMonth()+'/'+fecha.getFullYear());