<?php
	sleep(3);
	echo date("d.m.y");
	?>