<?php
	$nombre = $_POST['nombre'];
	$apellidos = $_POST['apellidos'];
	echo '<p>Mi nombre es '.$nombre. ' y mis apellidos son '.$apellidos.'.</p>';
?>