
$(document).ready(function (){
    $("#show").click(function (){
        $("#miDiv").load("html/index.html");
});
});